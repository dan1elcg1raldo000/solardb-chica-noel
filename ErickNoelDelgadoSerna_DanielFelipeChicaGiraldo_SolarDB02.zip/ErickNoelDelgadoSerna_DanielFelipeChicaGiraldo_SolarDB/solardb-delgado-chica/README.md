﻿# SolarDB — Gobernanza, ETL e IoT
## Integrantes
- INTEGRANTE 1: Erick Noel Delgado Serna
- INTEGRANTE 2: Daniel Felipe Chica Giraldo
## Curso
Bases de Datos I (SD1006) — Grupo 811 — 2026-II
## Descripción
Práctica de SolarDB Pascual centrada en gobernanza de datos, automatización ETL e IoT sobre PostgreSQL.

El flujo simula dos inversores que producen telemetría JSON, guarda los mensajes en una tabla de staging y transforma los datos hacia una tabla relacional. La clave primaria (dispositivo\_id, ts) y ON CONFLICT DO NOTHING permiten que la carga sea idempotente.
## Estructura
- data/lecturas.jsonl: datos JSONL de muestra.
- etl/simulador.py: genera telemetría de dos dispositivos.
- etl/run\_etl.py: punto único de entrada para la ingesta.
- sql/01\_tablas.sql: tablas de staging, destino y bitácora.
- sql/02\_carga.sql: transformación y carga idempotente.
- sql/03\_roles.sql: rol solar\_lector de solo lectura.
- docs/: PDF de la consulta.
## Requisitos
- PostgreSQL 15 o superior.
- Python 3.10+.
- psycopg2-binary.
## Preparación
1. Crear una base de datos llamada solardb.
1. Ejecutar sql/01\_tablas.sql.
1. Ejecutar sql/03\_roles.sql.
1. Instalar dependencias: pip install -r requirements.txt
1. Crear un .env local o definir DATABASE\_URL en el entorno.
1. Ejecutar: python etl/simulador.py
1. Ejecutar el pipeline: python etl/run\_etl.py
## Prueba de idempotencia
Ejecutar el pipeline dos veces con el mismo archivo y consultar:

SELECT COUNT(\*) FROM lectura\_demo;

El segundo ciclo no debe duplicar las claves (dispositivo\_id, ts) ya existentes.
## Evidencia de permisos
Con solar\_lector debe funcionar:

SELECT \* FROM lectura\_demo;

y debe fallar un INSERT sobre lectura\_demo.
## Programación horaria
Ejemplo de cron cada hora:

0 \* \* \* \* cd /ruta/al/repositorio && /usr/bin/python3 etl/run\_etl.py
## Participación

|Integrante|Aportes|
| :-: | :-: |
|Erick Noel Delgado Serna|Gobernanza de datos, SQL de tablas/roles, parte de la consulta y pruebas ETL|
|Daniel Felipe Chica Giraldo|ETL/JSON, IoT, documentación, README y pruebas de idempotencia|
## Seguridad
Nunca subir contraseñas, tokens ni cadenas de conexión reales. El archivo .env está excluido mediante .gitignore.
